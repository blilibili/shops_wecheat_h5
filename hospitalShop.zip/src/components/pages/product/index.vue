<template>
    <div>商品首页</div>
</template>

<script>
    export default {
        name: "index"
    }
</script>

<style scoped>

</style>

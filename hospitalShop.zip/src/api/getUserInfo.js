import {config} from './global'
export const requestGetUserInfo = (param , context) =>
{
  let url = config.website + '/api/getUserInfo';
  return context.$http.get(url , {params:param})
};

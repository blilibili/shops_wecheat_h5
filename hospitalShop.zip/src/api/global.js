export const config = {
  website: 'http://piglhd.site'
}
